const allowedOrigins=[
    'http://localhost:3000',
    'http://vscode.readyle.live:3000',
    'http://code.readyle.live:3000',
]
module.exports = allowedOrigins