const ROLES_LIST = ['admin', 'moderator','user']
module.exports = ROLES_LIST;